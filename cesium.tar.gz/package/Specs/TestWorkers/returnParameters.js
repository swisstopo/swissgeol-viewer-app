import { createTaskProcessorWorker } from "@cesium/engine";

export default createTaskProcessorWorker(function (parameters) {
  return parameters;
});
