# Box Vertex Colors

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Donated by Michael Feldstein for glTF testing.
