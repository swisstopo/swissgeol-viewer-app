# SimpleMorph

## Screenshot

![screenshot](screenshot/screenshot.png)

## Data layout

The following image shows the data layout of this sample:

![simpleMorphStructure](screenshot/simpleMorphStructure.png)

## License Information

Public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/))
