# Torus with `KHR_mesh_quantization`

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/))
