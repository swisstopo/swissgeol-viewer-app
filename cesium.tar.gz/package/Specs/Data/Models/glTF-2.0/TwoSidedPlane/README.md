# Two Sided Plane

## Screenshot

![screenshot](screenshot/screenshot.jpg)

## License Information

Donated by Norbert Nopper for glTF testing.
