# TriangleWithoutIndices

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/))

## Data layout

The following image shows the data layout of this sample:

![triangleWithoutIndices](screenshot/triangleWithoutIndices.png)
