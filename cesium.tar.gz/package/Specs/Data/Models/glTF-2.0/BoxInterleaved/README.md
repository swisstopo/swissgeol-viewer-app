# Box with interleaved position and normal attributes

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Donated by [Cesium](http://cesiumjs.org/) and interleaved by [AngeloReppucci](https://github.com/AngeloReppucci) for glTF testing.

This model is licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).
