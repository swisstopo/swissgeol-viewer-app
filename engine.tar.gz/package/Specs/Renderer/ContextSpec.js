import {
  Color,
  IndexDatatype,
  Buffer,
  BufferUsage,
  Context,
  ContextLimits,
} from "../../index.js";

import createContext from "../../../../Specs/createContext.js";

describe(
  "Renderer/Context",
  function () {
    let context;
    const webglStub = !!window.webglStub;

    beforeAll(function () {
      context = createContext();
      spyOn(Context, "_deprecationWarning");
    });

    afterAll(function () {
      context.destroyForSpecs();
    });

    it("has a unique ID", function () {
      const c = createContext();
      expect(c.id).toBeDefined();
      expect(c.id).not.toEqual(context.id);
      c.destroyForSpecs();
    });

    it("get canvas", function () {
      expect(context.canvas).not.toBeNull();
    });

    it("get stencilBits", function () {
      expect(context.stencilBits).toBeGreaterThanOrEqual(0);
    });

    it("get maximumCombinedTextureImageUnits", function () {
      expect(
        ContextLimits.maximumCombinedTextureImageUnits
      ).toBeGreaterThanOrEqual(8);
    });

    it("get maximumCubeMapSize", function () {
      expect(ContextLimits.maximumCubeMapSize).toBeGreaterThanOrEqual(16);
    });

    it("get maximumFragmentUniformVectors", function () {
      expect(
        ContextLimits.maximumFragmentUniformVectors
      ).toBeGreaterThanOrEqual(16);
    });

    it("get maximumTextureImageUnits", function () {
      expect(ContextLimits.maximumTextureImageUnits).toBeGreaterThanOrEqual(8);
    });

    it("get maximumRenderbufferSize", function () {
      expect(ContextLimits.maximumRenderbufferSize).toBeGreaterThanOrEqual(1);
    });

    it("get maximumTextureSize", function () {
      expect(ContextLimits.maximumTextureSize).toBeGreaterThanOrEqual(64);
    });

    it("get maximumVaryingVectors", function () {
      expect(ContextLimits.maximumVaryingVectors).toBeGreaterThanOrEqual(8);
    });

    it("get maximumVertexAttributes", function () {
      expect(ContextLimits.maximumVertexAttributes).toBeGreaterThanOrEqual(8);
    });

    it("get maximumVertexTextureImageUnits", function () {
      expect(
        ContextLimits.maximumVertexTextureImageUnits
      ).toBeGreaterThanOrEqual(0);
    });

    it("get maximumVertexUniformVectors", function () {
      expect(ContextLimits.maximumVertexUniformVectors).toBeGreaterThanOrEqual(
        1
      );
    });

    it("get minimumAliasedLineWidth", function () {
      expect(ContextLimits.minimumAliasedLineWidth).toBeLessThanOrEqual(1);
    });

    it("get maximumAliasedLineWidth", function () {
      expect(ContextLimits.maximumAliasedLineWidth).toBeGreaterThanOrEqual(1);
    });

    it("get minimumAliasedPointSize", function () {
      expect(ContextLimits.minimumAliasedPointSize).toBeLessThanOrEqual(1);
    });

    it("get maximumAliasedPointSize", function () {
      expect(ContextLimits.maximumAliasedPointSize).toBeGreaterThanOrEqual(1);
    });

    it("get maximumViewportWidth", function () {
      expect(ContextLimits.maximumViewportWidth).toBeGreaterThan(0);
    });

    it("get maximumViewportHeight", function () {
      expect(ContextLimits.maximumViewportHeight).toBeGreaterThan(0);
    });

    it("gets antialias", function () {
      const c = createContext({
        webgl: {
          antialias: false,
        },
      });
      expect(c.antialias).toEqual(false);
      c.destroyForSpecs();
    });

    it("gets the standard derivatives extension", function () {
      let fs = "";

      if (context.standardDerivatives && !context.webgl2) {
        fs += "#extension GL_OES_standard_derivatives : enable\n";
      }

      fs += "void main()\n" + "{\n";

      if (context.standardDerivatives) {
        fs += "  out_FragColor = vec4(dFdx(1.0), dFdy(1.0), 1.0, 1.0);\n";
      } else {
        fs += "  out_FragColor = vec4(1.0);\n";
      }

      fs += "}";

      const expected = context.standardDerivatives
        ? [0, 0, 255, 255]
        : [255, 255, 255, 255];
      expect({
        context: context,
        fragmentShader: fs,
      }).contextToRender(expected);
    });

    it("gets the element index uint extension", function () {
      if (context.elementIndexUint) {
        const buffer = Buffer.createIndexBuffer({
          context: context,
          sizeInBytes: 6,
          usage: BufferUsage.STREAM_DRAW,
          indexDatatype: IndexDatatype.UNSIGNED_INT,
        });
        expect(buffer).toBeDefined();
        buffer.destroy();
      } else {
        expect(function () {
          Buffer.createIndexBuffer({
            context: context,
            sizeInBytes: 6,
            usage: BufferUsage.STREAM_DRAW,
            indexDatatype: IndexDatatype.UNSIGNED_INT,
          });
        }).toThrowDeveloperError();
      }
    });

    it("gets the depth texture extension", function () {
      expect(context.depthTexture).toBeDefined();
    });

    it("gets the texture float extension", function () {
      expect(context.floatingPointTexture).toBeDefined();
    });

    it("gets texture filter anisotropic extension", function () {
      expect(context.textureFilterAnisotropic).toBeDefined();
    });

    it("gets texture filter anisotropic extension", function () {
      expect(context.textureFilterAnisotropic).toBeDefined();
    });

    it("gets maximum texture filter anisotropy", function () {
      if (context.textureFilterAnisotropic) {
        expect(
          ContextLimits.maximumTextureFilterAnisotropy
        ).toBeGreaterThanOrEqual(2);
      } else {
        expect(ContextLimits.maximumTextureFilterAnisotropy).toEqual(1);
      }
    });

    it("gets vertex array object extension", function () {
      expect(context.vertexArrayObject).toBeDefined();
    });

    it("get the fragment depth extension", function () {
      if (context.fragmentDepth && !context.webgl2) {
        return;
      }

      const fs =
        "void main()\n" +
        "{\n" +
        "  out_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n" +
        "}";

      expect({
        context: context,
        fragmentShader: fs,
        depth: 0.5,
      }).contextToRender([255, 0, 0, 255]);

      let fsFragDepth = "#extension GL_EXT_frag_depth : enable\n";

      fsFragDepth +=
        "void main()\n" +
        "{\n" +
        "    out_FragColor = vec4(0.0, 1.0, 0.0, 1.0);\n";

      if (context.fragmentDepth) {
        fsFragDepth += "    gl_FragDepth";
        if (!context.webgl2) {
          fsFragDepth += "EXT";
        }
        fsFragDepth += " = 0.0;\n";
      }

      fsFragDepth += "}\n";

      const expected = [0, 255, 0, 255];
      expect({
        context: context,
        fragmentShader: fsFragDepth,
        depth: 1.0,
        clear: false,
      }).contextToRender(expected);
    });

    it("get the draw buffers extension", function () {
      expect(context.drawBuffers).toBeDefined();
    });

    it("get the maximum number of draw buffers", function () {
      if (context.drawBuffers) {
        expect(ContextLimits.maximumDrawBuffers).toBeGreaterThanOrEqual(1);
      } else {
        expect(ContextLimits.maximumDrawBuffers).toEqual(1);
      }
    });

    it("get the maximum number of color attachments", function () {
      if (context.drawBuffers) {
        expect(ContextLimits.maximumColorAttachments).toBeGreaterThanOrEqual(4);
      } else {
        expect(ContextLimits.maximumColorAttachments).toEqual(1);
      }
    });

    it("can create a pick ID and retrieve an object by pick color", function () {
      const o = {};
      const pickId = context.createPickId(o);

      expect(pickId).toBeDefined();
      expect(context.getObjectByPickColor(pickId.color)).toBe(o);
    });

    it("throws when creating a pick ID without an object", function () {
      expect(function () {
        context.createPickId(undefined);
      }).toThrowDeveloperError();
    });

    it("returns undefined when retrieving an object by unknown pick color", function () {
      expect(context.getObjectByPickColor(Color.WHITE)).toBeUndefined();
    });

    it("throws when getObjectByPickColor is called without a color", function () {
      expect(function () {
        context.getObjectByPickColor(undefined);
      }).toThrowDeveloperError();
    });

    it("fails to construct (null canvas)", function () {
      expect(function () {
        return new Context();
      }).toThrowDeveloperError();
    });

    it("isDestroyed", function () {
      const c = createContext();
      expect(c.isDestroyed()).toEqual(false);
      c.destroyForSpecs();
      expect(c.isDestroyed()).toEqual(true);
    });

    it("destroying Context destroys objects in cache", function () {
      const c = createContext();
      const destroyableObject = jasmine.createSpyObj("destroyableObject", [
        "destroy",
      ]);
      c.cache.foo = destroyableObject;
      c.destroyForSpecs();
      expect(destroyableObject.destroy).toHaveBeenCalled();
    });

    it("non-destroyable objects are allowed in the cache", function () {
      const c = createContext();
      const nonDestroyableObject = {};
      c.cache.foo = nonDestroyableObject;
      c.destroyForSpecs();
    });

    it("returns the underling drawingBufferWidth", function () {
      const c = createContext(undefined, 1024, 768);
      expect(c.drawingBufferWidth).toBe(1024);
      c.destroyForSpecs();
    });

    it("returns the underling drawingBufferHeight", function () {
      const c = createContext(undefined, 1024, 768);
      expect(c.drawingBufferHeight).toBe(768);
      c.destroyForSpecs();
    });

    it("requestWebgl1 works", function () {
      const c1 = createContext({
        requestWebgl1: true,
      });
      expect(c1._webgl2).toBe(false);

      if (!webglStub) {
        const c2 = createContext({
          requestWebgl1: false,
        });
        expect(c2._webgl2).toBe(true);
      }
    });
  },
  "WebGL"
);
